<?php
mysql_close();
?>