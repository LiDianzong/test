# TicketSell
在线火车售票系统

### 该项目使用PHP编码完成，，是我们学校实训完成的较大型项目

有详细的设计文档:https://github.com/MilkyWayWll/TicketSell/blob/master/%E7%81%AB%E8%BD%A6%E8%AE%A2%E7%A5%A8%E7%B3%BB%E7%BB%9F%E8%AE%BE%E8%AE%A1%E6%96%87%E6%A1%A3%20.docx
