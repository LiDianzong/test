<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<style type="text/css">
.style {
	font-size: 16px;
	color: #F63;
}
</style>
<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td height="4" background="images/line.gif"></td>
  </tr>
  <tr>
    <td height="44" bgcolor="#F0F0F0"><table width="100%" height="60px" border="0" cellpadding="0" cellspacing="0">
      <tr>
        <td width="100%" height="75" align="center">
        <table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td height="20" align="center">&nbsp;</td>
          </tr>
          <tr>
            <td height="23" align="center"><strong class="style">2017 沸点101℃</strong></td>
          </tr>
      </table>
          <p class="style">版权所有 © 2017 沸点101. 九江学院B1531</p></td>
      </tr>
    </table></td>
  </tr>
</table>
