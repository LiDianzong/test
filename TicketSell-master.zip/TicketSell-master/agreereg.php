<?php
 include("top.php");
?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<tr align= "left" valign="top" bgcolor="#F0F0F0"><?php include("left.php")?>
<div class="m_left" style=" width: 600px; height:380px; margin-left: 380px;margin-top: -400px;">
<table width="766" height="438" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="561" align="center" valign="top" bgcolor="#FFFFFF"><table width="557" height="350" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td width="557" height="46"><div align="center">欢迎注册！</div></td>
      </tr>
      <tr>
        <td height="255"><table width="500" height="350" border="0" align="center" cellpadding="0" cellspacing="1">
            <tr>
              <td height="325" bgcolor="#FFFFFF" valign="top">                
              <DIV style="HEIGHT:325px;WIDTH:500px"> &nbsp;&nbsp;<br>&nbsp;&nbsp;&nbsp; 用户协议<br>
              <br>
              <table width="400" border="0" align="center" cellpadding="0" cellspacing="0">
                <tr>
                  <td height="152" valign="top"><div align="center"> 　　用户同意此在线注册条款之效力如同用户亲自签字、盖章的书面条款一样，对用户具有法律约束力。<br />
　　用户进一步同意，用户进入会员注册程序即意味着用户同意了本注册条款的所有内容且只有用户完全同意所有服务条款并完成注册程序，才能成为正式用户。本注册条款自用户注册成功之日起在用户与电子商城之间产生法律效力。<br />
<br>
                      <br>
                  </div></td>
                </tr>
              </table>
              </div></td>
            </tr>
            <tr>
              <td height="25" bgcolor="#FFFFFF"><div align="center">
              <a href="index.php">不同意</a>&nbsp;&nbsp;
              <a href="reg.php">同意</a>
              </div>
              </td>
            </tr>
        </table></td>
      </tr>
    </table></td>
  </tr>
</table>
	</div>
	<div class="down" style=" width: auto; height: 120px; margin-top: 30px;">
		<?php include("bottom.php");
?>
	</div>
